package com.gadgets.online.model.stock;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "gms_gadgets", catalog = "gmsdb")
public class Gadgets extends Electronics {

	@Enumerated(EnumType.STRING)
	@Column(name="gadgets_category",length = 20)
	private Category category;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "gms_items_images", joinColumns = @JoinColumn(name = "id"), inverseJoinColumns = @JoinColumn(name = "image_id"))
	private Collection<Images> images = new HashSet<Images>();

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Collection<Images> getImages() {
		return images;
	}

	public void setImages(Collection<Images> images) {
		this.images = images;
	}

	public Gadgets() {
		super();
		// TODO Auto-generated constructor stub
	}

}
