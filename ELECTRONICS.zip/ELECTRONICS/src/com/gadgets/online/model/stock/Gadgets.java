package com.gadgets.online.model.stock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

@Entity
@Table(name = "gms_gadgets", catalog = "gmsdb")
public class Gadgets extends Electronics {

	@Enumerated(EnumType.STRING)
	@Column(name="gadgets_category",length = 20)
	private Category category;

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	public Gadgets() {
		super();
		// TODO Auto-generated constructor stub
	}

}
