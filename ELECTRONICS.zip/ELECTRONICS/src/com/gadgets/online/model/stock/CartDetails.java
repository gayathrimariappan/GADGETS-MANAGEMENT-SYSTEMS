package com.gadgets.online.model.stock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gms_cart_details", catalog = "gmsdb")
public class CartDetails {
	@Id
	@Column(name = "gadgets_id")
	private String gadgetsId;
	
	@Column(name = "email_id")
	private String emailId;

	public String getGadgetsId() {
		return gadgetsId;
	}

	public void setGadgetsId(String gadgetsId) {
		this.gadgetsId = gadgetsId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	

}
