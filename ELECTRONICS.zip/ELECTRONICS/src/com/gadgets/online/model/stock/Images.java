package com.gadgets.online.model.stock;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gms_images", catalog = "gmsdb")
//@TableGenerator(name = "electronics_tab_gen", allocationSize = 1, initialValue = 100, catalog = "gmsdb", table = "gms_table_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "id")
public class Images implements Serializable {
	private static final long serialVersionUID = 2647790843336994774L;
	
	@Id
	//@GeneratedValue(generator = "electronics_tab_gen", strategy = GenerationType.TABLE)
	private Integer id;
	
	@Column(name = "url")
	private String url;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
