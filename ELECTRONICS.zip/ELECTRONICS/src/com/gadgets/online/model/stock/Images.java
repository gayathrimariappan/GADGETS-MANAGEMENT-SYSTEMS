package com.gadgets.online.model.stock;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gms_images", catalog = "gmsdb")

public class Images implements Serializable {
	private static final long serialVersionUID = 2647790843336994774L;
	@Id
	@Column(name = "image_id")
	private String id;
	@Column(name = "image_name")
	private String name;
	@Column(name = "image_url")
	private String url;

	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}


	


}
