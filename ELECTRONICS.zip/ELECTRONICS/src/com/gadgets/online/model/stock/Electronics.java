package com.gadgets.online.model.stock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "gms_electronics", catalog = "gmsdb")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@TableGenerator(name = "electronics_tab_gen", allocationSize = 1, initialValue = 1, catalog = "gmsdb", table = "gms_table_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "id")
public class Electronics {
	@Id
	@GeneratedValue(generator = "electronics_tab_gen", strategy = GenerationType.TABLE)
	@Column(name = "id")
	private Integer id;

	@Column(name = "gadgets_id")
	private String gId;
	
	@Column(name = "gadgets_name")
	private String name;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "gadgets_description")
	private Description description;
	
	@Column(name = "gadgets_price")
	private Integer price;
	
	@Column(name = "gadgets_available_count")
	private Integer availableCount;
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Description getDescription() {
		return description;
	}

	public void setDescription(Description description) {
		this.description = description;
	}
	
	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getAvailableCount() {
		return availableCount;
	}

	public void setAvailableCount(Integer availableCount) {
		this.availableCount = availableCount;
	}

	public String getgId() {
		return gId;
	}

	public void setgId(String gId) {
		this.gId = gId;
	}

	public Electronics() {
		super();
		// TODO Auto-generated
	}

}
