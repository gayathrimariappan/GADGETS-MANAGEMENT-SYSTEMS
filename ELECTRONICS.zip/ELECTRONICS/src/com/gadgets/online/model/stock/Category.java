package com.gadgets.online.model.stock;

public enum Category {
	AUDIOVIDEO,CAMERA,COMPUTER,ENTERTAINMENT,MOBILE;
}
