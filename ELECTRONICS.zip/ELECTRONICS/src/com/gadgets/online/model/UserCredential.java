package com.gadgets.online.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@SuppressWarnings("deprecation")
@Entity
@org.hibernate.annotations.Entity(dynamicUpdate = true)
@Table(name = "gms_user_credential", catalog = "gmsdb")
public class UserCredential implements Serializable {

	private static final long serialVersionUID = -5018926889423003164L;

	@Id
	@Column(name = "email_id")
	private String emailId;

	@Column(name = "password")
	private String password;

	@Column(name = "auth_key")
	private String authKey;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "status")
	private Boolean activated;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "credential")
	private UserProfile profile;

	public String getEmailId() {
		return emailId;
	}

	public String getPassword() {
		return password;
	}

	public String getAuthKey() {
		return authKey;
	}

	public Boolean getActivated() {
		return activated;
	}

	public UserProfile getProfile() {
		return profile;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	public void setProfile(UserProfile profile) {
		this.profile = profile;
	}

	public void setActivated(Boolean activated) {
		this.activated = activated;
	}

}
