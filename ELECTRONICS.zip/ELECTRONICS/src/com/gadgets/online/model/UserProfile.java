package com.gadgets.online.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "gms_user_profile", catalog = "gmsdb", uniqueConstraints = {
		@UniqueConstraint(columnNames = "phone_number", name = "gms_user_profile_phone_unq") })
@TableGenerator(name = "prof_tab_gen", allocationSize = 1, initialValue = 1, catalog = "gmsdb", table = "gms_table_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "prof_id")
public class UserProfile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "prof_id")
	@GeneratedValue(generator = "prof_tab_gen", strategy = GenerationType.TABLE)
	private Integer id;

	@Column(name = "first_name",nullable=false)
	private String firstName;

	@Column(name = "last_name",nullable=false)
	private String lastName;

	@Column(name = "phone_number",nullable=false)
	private String phoneNumber;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "email_id")
	private UserCredential credential;

	@Embedded
	private Address address;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public UserProfile() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserCredential getCredential() {
		return credential;
	}

	public void setCredential(UserCredential credential) {
		this.credential = credential;
	}

}
