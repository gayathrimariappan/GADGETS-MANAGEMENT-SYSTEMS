package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gadgets.online.serv.GadgetService;


/**
 * Servlet implementation class GadgetServlet
 */
@WebServlet("/addgadget")
public class AddGadgetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddGadgetServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {
			String id = request.getParameter("g_id");
			String name = request.getParameter("g_name");
			String color = request.getParameter("g_color");
			String storage = request.getParameter("g_storage");
			String features = request.getParameter("g_features");
			String type = request.getParameter("g_type");
			String price = request.getParameter("g_price");
			String availableCount = request.getParameter("g_available");
			if (id == null || id.isEmpty() || name == null || name.isEmpty()|| color == null || color.isEmpty()
					|| storage == null || storage.isEmpty()|| features == null || features.isEmpty() || 
					type == null || type.isEmpty() || price == null || price.isEmpty()|| 
					availableCount == null ||availableCount.isEmpty()) {
				out.println("All Fields needed to provide this service");
			} 
			else {
				
				GadgetService.insert(id, name, color, storage, features, type,price,availableCount);
				request.getRequestDispatcher("admincrud.html").include(request, response);
				
			}
			out.println(" <a href='index.html'>HOME PAGE</a>");
		}

	}
}