package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gadgets.online.serv.GadgetService;

/**
 * Servlet implementation class UpdateGadgetServlet
 */
@WebServlet("/updategadget")
public class UpdateGadgetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateGadgetServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {
			String id = request.getParameter("g_id");
			String color = request.getParameter("g_color");
			String features = request.getParameter("g_features");
			String storage = request.getParameter("g_storage");
			String price = request.getParameter("g_price");
			String availableCount = request.getParameter("g_available");
			System.out.println(id+color+features+storage+price+availableCount);
			if (id == null || id.isEmpty() || color == null || color.isEmpty()|| storage == null || storage.isEmpty()
					|| features == null || features.isEmpty() || price == null || price.isEmpty()|| 
					availableCount == null ||availableCount.isEmpty()) {
				out.println("All Fields needed to provide this service");
			} 
			else {
				GadgetService.update(id,color,storage, features, price, availableCount);
				request.getRequestDispatcher("admincrud.html").include(request, response);
			}
			
		}
		
}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
