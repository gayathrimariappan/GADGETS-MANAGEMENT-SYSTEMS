package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gadgets.online.serv.CredentialService;
import com.gadgets.online.serv.CredentialStatus;

/**
 * Servlet implementation class UpdatePasswordServlet
 */
@WebServlet("/update")
public class UpdatePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdatePasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {
			String emailId = request.getParameter("email");
			String oldPassword = request.getParameter("opassword");
			String newPassword = request.getParameter("npassword");
				CredentialService upassword = new CredentialService();
				if (!(upassword.availability(emailId))) {
					out.println("INVALID EMAIL-ID");
					request.getRequestDispatcher("updatepassword.html").include(request, response);
				} else {
					CredentialStatus status = upassword.validate(emailId, oldPassword);
					if (status.compareTo(CredentialStatus.ERROR) != 0){
						upassword.updatePassword(emailId, oldPassword, newPassword);
						
						request.getRequestDispatcher("signin.html").include(request, response);
					}
					else{
						out.println("<h3><i>IN CORRECT OLD PASSWORD </i></h3>");
						request.getRequestDispatcher("updatepassword.html").include(request, response);
					}
					
				}
				out.println(" <a href='index.html'>HOME PAGE</a>");
			}
		
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
