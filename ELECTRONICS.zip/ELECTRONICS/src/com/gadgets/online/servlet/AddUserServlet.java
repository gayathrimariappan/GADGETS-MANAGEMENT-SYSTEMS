package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gadgets.online.serv.UserService;

/**
 * Servlet implementation class AddUserServlet
 */
@WebServlet("/adduser")
public class AddUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {

			String firstName = request.getParameter("fname");
			String lastName = request.getParameter("lname");
			String emailId = request.getParameter("email");
			String password = request.getParameter("password");
			String phoneNo = request.getParameter("phoneno");
			String houseNumber = request.getParameter("dno");
			String streetName = request.getParameter("sname");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String country = request.getParameter("country");
			String pinCode = request.getParameter("pcode");
			UserService.insert(firstName, lastName, emailId, password, phoneNo, houseNumber, streetName, city, state,
					country, pinCode);
			out.println(
					" <h1 style='color:red;font-family:Arabic Typesetting;text-align:center background-color:powderblue'>Successfully Registered!!</h1>");
			out.println(" <a href='signin.html'>Sign In!!!</a>");
			out.println(" <a href='index.html'>HOME PAGE</a>");
		}
	}

}
