package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gadgets.online.model.UserCredential;
import com.gadgets.online.serv.CredentialService;
import com.gadgets.online.serv.CredentialStatus;
import com.gadgets.online.serv.UserService;

/**
 * Servlet implementation class CheckUserServlet
 */
@WebServlet("/checkuser")
public class CheckUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CheckUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {
			String emailId = request.getParameter("email");
			String password = request.getParameter("password");
			
				CredentialService credential = new CredentialService();
				CredentialStatus status = credential.validate(emailId, password);
				UserCredential usercredit = new UserCredential();
			
				if (status.compareTo(CredentialStatus.NOT_ACTIVATED) == 0) {
					credential.activate(emailId, UserService.findKey(emailId));
					request.getRequestDispatcher("index.html").include(request, response);
				} else if (status.compareTo(CredentialStatus.LOGGED) == 0) {	
					request.getRequestDispatcher("gadgets.html").include(request, response);
				} else if (status.compareTo(CredentialStatus.NOT_AVAILABLE) == 0) {
					System.out.println("not available block");
					out.println("<h1 style='color:black;font-family:Arabic Typesetting;text-align:center'>Not a Registered User</h1>");
					out.println("<h1 style='color:black;font-family:Arabic Typesetting;text-align:center'>Fill The Details To Register!!!</h1>");
					request.getRequestDispatcher("signup.html").include(request, response);
				} else if (status.compareTo(CredentialStatus.SUCCESS) == 0) {
					System.out.println("successs block");
					request.getRequestDispatcher("gadgets.html").include(request, response);
				} else if (status.compareTo(CredentialStatus.ERROR) == 0) {
					System.out.println("error block");
					out.println("<h3 style='color:black;font-family:Arabic Typesetting;text-align:center'>Incorrect Password</h3>");
					request.getRequestDispatcher("signin.html").include(request, response);
				} else{
					out.println(status);
				out.println(" <a href='index.html'>HOME PAGE</a>");
				}
				String key = UserService.findKey(emailId);
				if(status.compareTo(CredentialStatus.NOT_ACTIVATED)==0 || status.compareTo(CredentialStatus.SUCCESS)==0 || 
						status.compareTo(CredentialStatus.LOGGED)==0){
					Cookie cookie = new Cookie("user_emailId",emailId);
					cookie.setMaxAge(24*60*60*7);
					response.addCookie(cookie);
					cookie = new Cookie("user_key",key);
					cookie.setMaxAge(24*60*60*7);
					response.addCookie(cookie);
					System.out.println(cookie+" "+emailId+" "+key);
				}
			}
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
