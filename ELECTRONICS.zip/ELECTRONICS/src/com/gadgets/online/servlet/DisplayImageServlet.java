package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.gadgets.online.model.stock.Images;
import com.gadgets.online.serv.FactoryService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class DisplayImageServlet
 */
@WebServlet("/displayimage")
public class DisplayImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayImageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/json");
		try (PrintWriter out = response.getWriter()) {
			SessionFactory sf = new FactoryService().get();
			Session session = sf.openSession();
			String hql = "FROM Images";
			Query query = session.createQuery(hql);
			List<Images> images = query.getResultList();
			JSONObject jsonData = new JSONObject();
			JSONArray jArray = new JSONArray();
			for (Images var :  images ) {
				jsonData.put("Image Id",var.getId());
				jsonData.put("Image Name",var.getName());
				jsonData.put("Image Url",var.getUrl());
				jArray.add(jsonData);
			}
			out.println(jArray.toString());
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
