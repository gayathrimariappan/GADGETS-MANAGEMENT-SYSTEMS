package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.gadgets.online.model.UserProfile;
import com.gadgets.online.model.stock.Gadgets;
import com.gadgets.online.serv.FactoryService;
import com.gadgets.online.serv.UserService;

/**
 * Servlet implementation class PaymentServlet
 */
@WebServlet("/paymentservlet")
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		try (PrintWriter out = response.getWriter()) {
			UserService user = new UserService();
			String emailId = user.getLoggedUser();
			String gadgetsurl = request.getParameter("imageurl");
			
			SessionFactory sf = new FactoryService().get();
			Session session = sf.openSession();
			session.beginTransaction();
			
			out.print("<img src="+gadgetsurl+" width='300px' height='300px' />");
			
			String hql = "FROM UserProfile where email_id= :id";
			Query query = session.createQuery(hql);
			query.setParameter("id", emailId);
			out.println("<link rel=\"stylesheet\" href=\"css/bootstrap.css\">");
			List<UserProfile> profile = query.getResultList();
			for (UserProfile var : profile) {
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>"+var.getAddress().getNo()+","+
			var.getAddress().getStreetName()+"</h2>");
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>"+var.getAddress().getCity()+","+
			var.getAddress().getState()+","+var.getAddress().getCountry()+","+var.getAddress().getPinCode()+"</h2>");
			}
			request.getRequestDispatcher("product.html").include(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
