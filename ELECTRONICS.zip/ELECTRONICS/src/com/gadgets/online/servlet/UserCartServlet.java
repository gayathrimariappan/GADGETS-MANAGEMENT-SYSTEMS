package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.gadgets.online.model.stock.CartDetails;
import com.gadgets.online.model.stock.Images;
import com.gadgets.online.serv.FactoryService;
import com.gadgets.online.serv.UserService;

/**
 * Servlet implementation class UserCartServlet
 */
@WebServlet("/usercart")
public class UserCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {
			UserService user = new UserService();
			String emailId = user.getLoggedUser();
		SessionFactory sf = new FactoryService().get();
		Session session = sf.openSession();
		session.beginTransaction();
		Query q = session.createQuery("from CartDetails where email_id = :emailId ");
		q.setParameter("emailId",emailId);
		List<CartDetails> cart = q.getResultList();
		for(CartDetails var:cart){
			String id = var.getGadgetsId();
			Query v =session.createQuery("from Images where image_id=:value");
			v.setParameter("value", id);
			List<Images> img = v.getResultList();
			for(Images val:img){
				String url = val.getUrl();
				out.println("<img src='"+url+"'/>");
			}
		}
	}
}
		
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
