package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.gadgets.online.model.stock.Gadgets;
import com.gadgets.online.serv.FactoryService;
import com.gadgets.online.serv.UserService;

/**
 * Servlet implementation class GadgetsDetailsServlet
 */
@WebServlet("/gadgetsdetails")
public class GadgetsDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GadgetsDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		response.setContentType("text/html");
		String id = request.getParameter("imageid");
		String url = request.getParameter("imageurl");
		
		UserService user = new UserService();
		String email = user.getLoggedUser();
		
		String gid = "/ELECTRONICS/cartservlet?imageid="+id;
		String gurl = "/ELECTRONICS/paymentservlet?imageurl="+url;

		try (PrintWriter out = response.getWriter()) {
			
			SessionFactory sf = new FactoryService().get();
			Session session = sf.openSession();
			
			session.beginTransaction();
	
			String hql = "FROM Gadgets where gadgets_id = :id";
			Query query = session.createQuery(hql);
			query.setParameter("id", id);
			out.println("<link rel=\"stylesheet\" href=\"css/bootstrap.css\">");
			out.print("<img src="+url+" width='300px' height='300px' />");
			List<Gadgets> gadgets = query.getResultList();
			for (Gadgets var : gadgets) {
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>"+"Gadgets Name :"
			+	var.getName()+"</h2>");
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>Gadgets Type 	:"
						+	var.getCategory()+"</h2>");
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>Gadgets Color	:"
						+	var.getDescription().getColor()+"</h2>");
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>Gadgets Storage :"
						+var.getDescription().getStorage()+"</h2>");
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>Gadgets Features	:"
						+	var.getDescription().getFeatures()+"</h2>");
				out.println("<h2 style='color:black;font-family:Arabic Typesetting;text-align:center'>Gadgets Price	:"
						+	var.getPrice()+"</h2>");
			}
			
			out.println("<a class='btn btn-primary btn-sm' href='"+gid+"'>ADD TO CART!!!</a>");
			out.println("<a class='btn btn-primary btn-sm' href='"+gurl+"'>BOOK NOW!!!</a>");
			session.getTransaction().commit();
			session.close();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
