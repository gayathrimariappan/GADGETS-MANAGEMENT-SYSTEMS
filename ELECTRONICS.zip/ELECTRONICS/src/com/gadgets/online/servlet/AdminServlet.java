package com.gadgets.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.getWriter();
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {
			String userName = request.getParameter("uname");
			String password = request.getParameter("password");
			if(userName.equalsIgnoreCase("admin") && (password.equalsIgnoreCase("admin"))){
				request.getRequestDispatcher("admincrud.html").include(request, response);
			}
			else{
				out.println("<h2 style='color:red;font-family:Arabic Typesetting;text-align:center'>Not a Admin</h2>");
			}
			out.println(" <a href='index.html'>HOME PAGE</a>");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
