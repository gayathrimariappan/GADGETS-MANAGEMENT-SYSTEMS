package com.gadgets.online.serv;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.gadgets.online.model.stock.Category;
import com.gadgets.online.model.stock.Description;
import com.gadgets.online.model.stock.Gadgets;
import com.gadgets.online.model.stock.Images;


public class GadgetService {
	public static void insert(String id, String name, String color, String storage, String features, String type,
			String price, String availableCount,String imageId,String imageName,String url) {
		SessionFactory sf = new FactoryService().get();
		Session session = sf.openSession();
		session.beginTransaction();

		Images image = new Images();
		image.setId(imageId);
		image.setName(imageName);
		image.setUrl(url);
		
		
		Description description = new Description();
		description.setColor(color);
		description.setStorage(storage);
		description.setFeatures(features);
		
		Gadgets gadgets = new Gadgets();
		gadgets.setgId(id);
		gadgets.setName(name);
		gadgets.setDescription(description);
		gadgets.setPrice(Integer.valueOf(price));
		gadgets.setAvailableCount(Integer.valueOf(availableCount));
		if (type.equalsIgnoreCase("MOBILE") == true)
			gadgets.setCategory(Category.MOBILE);
		if (type.equalsIgnoreCase("AUDIOVIDEO") == true)
			gadgets.setCategory(Category.AUDIOVIDEO);
		if (type.equalsIgnoreCase("CAMERA") == true)
			gadgets.setCategory(Category.CAMERA);
		if (type.equalsIgnoreCase("COMPUTER") == true)
			gadgets.setCategory(Category.COMPUTER);
		if (type.equalsIgnoreCase("ENTERTAINMENT") == true)
			gadgets.setCategory(Category.ENTERTAINMENT);
		
		
		session.save(description);
		session.save(gadgets);
		session.save(image);

		session.getTransaction().commit();
		session.close();

	}

	public static void update(String id, String color, String storage, String features, String price,
			String availableCount) {
		SessionFactory sf = new FactoryService().get();
		Session session = sf.openSession();
		session.beginTransaction();
		
		Query q = session.createQuery("from Gadgets where gadgets_id = :id ");
		q.setParameter("id", id);
		Gadgets gadgets = (Gadgets)((org.hibernate.Query) q).list().get(0);
		Description description = new Description();
		description.setColor(color);
		description.setFeatures(features);
		description.setStorage(storage);
		gadgets.setAvailableCount(Integer.valueOf(availableCount));
		gadgets.setPrice(Integer.valueOf(price));
		session.update(gadgets);
		
		/*String hql = "update Gadgets set gadgets_price = :price,gadgets_available_count =:availableCount where gadgets_id = :id";
		Query query = session.createQuery(hql);
		query.setParameter("price", price);
		query.setParameter("id", id);
		query.setParameter("availableCount", availableCount);

		query.executeUpdate();*/
		session.getTransaction().commit();
		session.close();
	}

	public static void delete(String id) {
		String hql = "delete from Gadgets where gadgets_id = :id";

		SessionFactory sf = new FactoryService().get();
		Session session = sf.openSession();
		session.beginTransaction();

		Query query = session.createQuery(hql);
		query.setParameter("id", id);

		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	

}
