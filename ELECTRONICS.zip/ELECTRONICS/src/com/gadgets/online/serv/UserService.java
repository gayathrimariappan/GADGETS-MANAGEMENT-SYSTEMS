package com.gadgets.online.serv;

import java.util.List;

import javax.persistence.Query;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.gadgets.online.model.Address;
import com.gadgets.online.model.UserCredential;
import com.gadgets.online.model.UserProfile;

public class UserService {
	public static void insert(String firstName, String lastName, String emailId, String password, String phoneNumber,
			String doorNo, String streetName, String city, String state, String country, String pinCode) {
		SessionFactory sf = new FactoryService().get();
		Session session = sf.openSession();
		session.beginTransaction();
		
		CredentialService service = new CredentialService();
		
		Address address = new Address();
		address.setNo(doorNo);
		address.setStreetName(streetName);
		address.setCity(city);
		address.setCountry(country);
		address.setState(state);
		address.setPinCode(Integer.valueOf(pinCode));
			
		UserCredential credential = new UserCredential();
		credential.setEmailId(emailId);
		credential.setPassword(password);
		credential.setActivated(true);
		
		UserProfile user = new UserProfile();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setPhoneNumber(phoneNumber);
		user.setCredential(credential);
		user.setAddress(address);
		
		service.create(emailId,password);                      
		credential.setProfile(user);
		
		session.save(user);
		session.getTransaction().commit();
		session.close();

	}
public static String findKey(String emailId){
	String key=null;
	SessionFactory sf = new FactoryService().get();
	Session session = sf.openSession();
	session.beginTransaction();
	
	String hql = "FROM UserCredential WHERE email_id=:email";
	Query query = session.createQuery(hql);
	query.setParameter("email", emailId);
	
	List<UserCredential> credential = query.getResultList();
	for(UserCredential var:credential){
		key = var.getAuthKey();
	}
	return key;
}
public static boolean logout(HttpServletResponse response,String emailid,String code){
	boolean status = false;
	SessionFactory sf = new FactoryService().get();
	Session session = sf.openSession();
	session.beginTransaction();
	
	UserCredential user = session.get(UserCredential.class, emailid);

	if(user!=null && user.getAuthKey().equals(code)){
		Cookie cookie = new Cookie("user_emailId","");
		cookie.setMaxAge(0);
		response.addCookie(cookie);
		cookie = new Cookie("user_key","");
		cookie.setMaxAge(0);
		response.addCookie(cookie);
		user.setAuthKey("");
		status = true;
		session.update(user);
	}
	session.getTransaction().commit();
	session.close();
	return status;
	
}
public static String getLoggedUser(){
	String key ="";
	
	SessionFactory sf = new FactoryService().get();
	Session session = sf.openSession();
	session.beginTransaction();
	
	String hql = "FROM UserCredential";
	Query query = session.createQuery(hql);
	
	List<UserCredential> credential = query.getResultList();
	for(UserCredential var:credential){
		if(var.getAuthKey().compareTo("")!=0 && var.getActivated()){
			System.out.println(var.getEmailId());
			key = var.getEmailId();
			break;
		}
	}
	
	return key;
}
} 